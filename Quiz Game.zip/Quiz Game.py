print("Welcome to the Pakistan Quiz!")
Quiz = input("Are you ready for the quiz? (Y/N): ").strip().capitalize()

if Quiz == "N":
    print("Goodbye!")
else:
    score = 0

    Q1 = input("When did Pakistan gain independence from British rule? ").strip().lower()
    if Q1 == "14 august 1947":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is 14 August 1947.")
        score -= 1

    Q2 = input("Who was the first Governor-General of Pakistan? ").strip().lower()
    if Q2 == "muhammad ali jinnah":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is Muhammad Ali Jinnah.")
        score -= 1

    Q3 = input("Which city is known as the 'City of Gardens' in Pakistan? ").strip().lower()
    if Q3 == "lahore":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is Lahore.")
        score -= 1

    Q4 = input("What is the national language of Pakistan? ").strip().lower()
    if Q4 == "urdu":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is Urdu.")
        score -= 1

    Q5 = input("Which river is the longest in Pakistan? ").strip().lower()
    if Q5 == "indus":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is Indus River.")
        score -= 1

    Q6 = input("What is the name of Pakistan’s national poet? ").strip().lower()
    if Q6 == "allama iqbal":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is Allama Iqbal.")
        score -= 1

    Q7 = input("Which mountain is the highest in Pakistan? ").strip().lower()
    if Q7 == "k2":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is K2.")
        score -= 1

    Q8 = input("How many provinces does Pakistan have? ").strip().lower()
    if Q8 in ["4", "four", "4 provinces"]:
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is 4.")
        score -= 1

    Q9 = input("Who is known as the 'Father of Pakistan’s Nuclear Program'? ").strip().lower()
    if Q9 == "abdul qadeer khan":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is Abdul Qadeer Khan.")
        score -= 1

    Q10 = input("Which city is the capital of Pakistan? ").strip().lower()
    if Q10 == "islamabad":
        print("Correct!")
        score += 1
    else:
        print("Wrong! The correct answer is Islamabad.")
        score -= 1

    print(f"\nQuiz Finished! Your final score is: {score}/10")
